(function(){'use strict';const STORAGE_KEY='nibbly-privacy-v1';const TAP_WINDOW_MS=800;const TAPS_TO_EXIT=3;const EYE_EMOJI='👁️';const PRIVACY_IMG_PATH='images/privacy.png';let state={warnDisabled:false};let activeOverlayEl=null;let backgroundCalcEl=null;let closingByUs=false;let musicWasPlaying=false;let musicPausedByPrivacy=false;


function iconEl(name,fallbackEmoji,opts){
opts=opts||{};
const wrap=document.createElement('span');
wrap.className='pv-icon-slot';
wrap.style.display='inline-flex';
wrap.style.alignItems='center';
wrap.style.justifyContent='center';
wrap.setAttribute('aria-hidden','true');

let settled=false;
let tries=0;
const MAX_TRIES=25;
const RETRY_MS=200;

function applyVector(){
if(settled)return true;
if(window.NibblyIcons&&typeof window.NibblyIcons.get==='function'){
const html=window.NibblyIcons.get(name,{size:opts.size||20});
if(html){
wrap.innerHTML=html;
settled=true;
return true;
}
}
return false;
}

function applyFallback(){
if(settled)return;
if(opts.pngFallback){
const img=document.createElement('img');
img.src=opts.pngFallback;
img.alt='';
img.className='nib-vec-icon pv-vec-img';
img.setAttribute('aria-hidden','true');
img.style.width=(opts.size||20)+'px';
img.style.height=(opts.size||20)+'px';
img.style.objectFit='contain';
img.style.display='block';
img.onerror=function(){
wrap.innerHTML='';
if(fallbackEmoji)wrap.textContent=fallbackEmoji;
settled=true;
};
wrap.innerHTML='';
wrap.appendChild(img);
return;
}
if(fallbackEmoji)wrap.textContent=fallbackEmoji;
}

if(applyVector())return wrap;
applyFallback();

const iv=setInterval(function(){
tries++;
if(applyVector()||tries>=MAX_TRIES){
clearInterval(iv);
if(!settled){
settled=true;
if(!wrap.firstChild)applyFallback();
}
}
},RETRY_MS);

return wrap;
}

const TEXTS={es:{warnTitle:'Modo Privado',warnBody:'Si estás aquí para hacer trampa en clase, hazlo con responsabilidad. Puedes entrar aquí si entiendes que el profesor permite celulares sin conexión. Nibbly no es responsable de tu puntaje académico si el profesor te descubre.',warnDontShow:'No mostrar de nuevo',warnAccept:'Aceptar y continuar',warnCancel:'Cancelar',tipsTitle:'Recomendaciones de seguridad',tips1:'Usa una pantalla anti-espía (privacy screen protector)',tips2:'Baja el brillo del celular al usar la app',tips3:'No uses estos modos si la sala está oscura y hay riesgo de que la retroiluminación te delate',tips4:'Estas funciones también sirven para ocultar tu operadora telefónica (en Android) o las apps abiertas en PC',tips5:'Para usar los convertidores de bases y demás, debes salir de la pantalla completa',tipsClose:'Entendido',fabCalcTitle:'Calculadora privada',fabBlackTitle:'Pantalla negra (3 toques para salir)',calcPanicTitle:'Pantalla negra rápida',calcTipsTitle:'Recomendaciones',calcCloseTitle:'Cerrar',errDivZero:'No se puede dividir entre cero',errSqrt:'Raíz de número negativo'},en:{warnTitle:'Private Mode',warnBody:'If you are here to cheat in class, do it responsibly. You can enter here if you understand that the teacher allows offline phones. Nibbly is not responsible for your academic score if the teacher catches you.',warnDontShow:'Don\'t show again',warnAccept:'Accept and continue',warnCancel:'Cancel',tipsTitle:'Security recommendations',tips1:'Use an anti-spy screen protector (privacy screen protector)',tips2:'Lower your phone brightness when using the app',tips3:'Don\'t use these modes if the room is dark and backlight could give you away',tips4:'These features also help hide your carrier name (Android) or open apps on PC',tips5:'To use the base converters and other tools, exit fullscreen mode',tipsClose:'Got it',fabCalcTitle:'Private calculator',fabBlackTitle:'Black screen (3 taps to exit)',calcPanicTitle:'Quick black screen',calcTipsTitle:'Recommendations',calcCloseTitle:'Close',errDivZero:'Cannot divide by zero',errSqrt:'Square root of negative number'}};function getLang(){try{const raw=localStorage.getItem('nibbly-settings-v2');if(raw){const s=JSON.parse(raw);if(s&&s.lang==='en')return'en';}}catch(e){}return'es';}function t(key){const lang=getLang();return(TEXTS[lang]&&TEXTS[lang][key])||TEXTS.es[key]||key;}function loadState(){try{const raw=localStorage.getItem(STORAGE_KEY);if(raw)state=Object.assign(state,JSON.parse(raw));}catch(e){}}function saveState(){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(state));}catch(e){}}

function pauseMusicForPrivacy(){if(musicPausedByPrivacy)return;const M=window.__nibblyMusic;if(!M||typeof M.isPlaying!=='function')return;try{if(M.isPlaying()){musicWasPlaying=true;M.pause();musicPausedByPrivacy=true;}}catch(e){}}
function resumeMusicFromPrivacy(){if(!musicPausedByPrivacy)return;const wasPlaying=musicWasPlaying;musicPausedByPrivacy=false;musicWasPlaying=false;if(!wasPlaying)return;const M=window.__nibblyMusic;if(!M)return;try{
if(typeof M.play==='function'){M.play();}
else if(typeof M.resume==='function'){M.resume();}
}catch(e){}}
function isFullscreen(){return!!(document.fullscreenElement||document.webkitFullscreenElement||document.mozFullScreenElement||document.msFullscreenElement);}function enterFullscreen(el){if(!el)return;const fn=el.requestFullscreen||el.webkitRequestFullscreen||el.webkitRequestFullScreen||el.mozRequestFullScreen||el.msRequestFullscreen;if(!fn)return;try{const p=fn.call(el);if(p&&typeof p.catch==='function')p.catch(function(){});}catch(e){}}function exitFullscreen(){if(!isFullscreen())return;const fn=document.exitFullscreen||document.webkitExitFullscreen||document.webkitCancelFullScreen||document.mozCancelFullScreen||document.msExitFullscreen;if(!fn)return;try{const p=fn.call(document);if(p&&typeof p.catch==='function')p.catch(function(){});}catch(e){}}function rescueKeyboardAfterFullscreen(){const attempt=()=>{try{if(document.activeElement&&document.activeElement.blur){try{document.activeElement.blur();}catch(e){}}const dummy=document.createElement('input');dummy.type='text';dummy.setAttribute('autocomplete','off');dummy.setAttribute('autocorrect','off');dummy.setAttribute('autocapitalize','off');dummy.setAttribute('spellcheck','false');dummy.setAttribute('tabindex','-1');dummy.setAttribute('aria-hidden','true');dummy.style.cssText='position:fixed;top:0;left:0;width:1px;height:1px;'+'padding:0;border:0;font-size:16px;'+'opacity:0.01;pointer-events:none;z-index:-1;';document.body.appendChild(dummy);try{dummy.focus({preventScroll:true});}catch(e){try{dummy.focus();}catch(e2){}}try{dummy.click();}catch(e){}setTimeout(()=>{try{dummy.blur();}catch(e){}try{dummy.remove();}catch(e){}window.dispatchEvent(new Event('resize'));},60);}catch(e){}};attempt();setTimeout(attempt,120);setTimeout(attempt,350);setTimeout(attempt,700);}function closeActiveOverlay(){const el=activeOverlayEl;activeOverlayEl=null;if(!el)return;closingByUs=true;exitFullscreen();setTimeout(function(){closingByUs=false;},300);try{el.remove();}catch(e){}resumeMusicFromPrivacy();}function exitBlackScreen(){const el=activeOverlayEl;if(!el)return;const mode=el.dataset.mode||'';activeOverlayEl=null;closingByUs=true;exitFullscreen();setTimeout(function(){closingByUs=false;},300);try{el.remove();}catch(e){}if(mode==='returnToCalc'&&backgroundCalcEl){const calcEl=backgroundCalcEl;backgroundCalcEl=null;calcEl.style.display='';activeOverlayEl=calcEl;}else{resumeMusicFromPrivacy();}rescueKeyboardAfterFullscreen();}function onFullscreenChange(){if(closingByUs)return;if(!isFullscreen()&&activeOverlayEl){const el=activeOverlayEl;if(el.classList&&el.classList.contains('pv-black-screen')){exitBlackScreen();}else{activeOverlayEl=null;try{el.remove();}catch(e){}resumeMusicFromPrivacy();}}if(!isFullscreen()){rescueKeyboardAfterFullscreen();}}document.addEventListener('fullscreenchange',onFullscreenChange);document.addEventListener('webkitfullscreenchange',onFullscreenChange);document.addEventListener('mozfullscreenchange',onFullscreenChange);document.addEventListener('MSFullscreenChange',onFullscreenChange);function el(tag,attrs,children){const node=document.createElement(tag);if(attrs){for(const k in attrs){if(k==='class')node.className=attrs[k];else if(k==='text')node.textContent=attrs[k];else if(k==='html')node.innerHTML=attrs[k];else if(k==='style'&&typeof attrs[k]==='object'){for(const sk in attrs[k])node.style[sk]=attrs[k][sk];}else if(k.startsWith('data-')||k.startsWith('aria-')||k==='id'||k==='title'||k==='type'){node.setAttribute(k,attrs[k]);}else{node[k]=attrs[k];}}}if(children){if(Array.isArray(children))children.forEach(c=>c&&node.appendChild(c));else if(typeof children==='string')node.textContent=children;else node.appendChild(children);}return node;}function showWarning(callback){const overlay=el('div',{class:'pv-overlay pv-warning-overlay'});const modal=el('div',{class:'pv-warning'});

const warnIconWrap=el('div',{class:'pv-warning-icon'});
warnIconWrap.appendChild(iconEl('warning','⚠️',{size:48}));
modal.appendChild(warnIconWrap);
modal.appendChild(el('h2',{class:'pv-warning-title',text:t('warnTitle')}));modal.appendChild(el('p',{class:'pv-warning-body',text:t('warnBody')}));const checkWrap=el('label',{class:'pv-warning-check'});const checkbox=el('input',{type:'checkbox'});checkWrap.appendChild(checkbox);checkWrap.appendChild(el('span',{text:t('warnDontShow')}));modal.appendChild(checkWrap);const btnRow=el('div',{class:'pv-warning-btns'});const cancelBtn=el('button',{class:'pv-btn-cancel',type:'button',text:t('warnCancel')});const acceptBtn=el('button',{class:'pv-btn-accept',type:'button',text:t('warnAccept')});btnRow.appendChild(cancelBtn);btnRow.appendChild(acceptBtn);modal.appendChild(btnRow);overlay.appendChild(modal);document.body.appendChild(overlay);const close=()=>overlay.remove();cancelBtn.addEventListener('click',close);overlay.addEventListener('click',(e)=>{if(e.target===overlay)close();});acceptBtn.addEventListener('click',()=>{if(checkbox.checked){state.warnDisabled=true;saveState();}close();if(typeof callback==='function')callback();});}function ensureWarning(callback){if(state.warnDisabled){callback();return;}showWarning(callback);}function openTips(){const overlay=el('div',{class:'pv-overlay pv-tips-overlay'});const modal=el('div',{class:'pv-tips'});modal.appendChild(el('h2',{class:'pv-tips-title',text:t('tipsTitle')}));const list=el('ul',{class:'pv-tips-list'});['tips1','tips2','tips3','tips4','tips5'].forEach(k=>{list.appendChild(el('li',{text:t(k)}));});modal.appendChild(list);const closeBtn=el('button',{class:'pv-btn-accept',type:'button',text:t('tipsClose')});closeBtn.addEventListener('click',()=>overlay.remove());modal.appendChild(closeBtn);overlay.appendChild(modal);overlay.addEventListener('click',(e)=>{if(e.target===overlay)overlay.remove();});document.body.appendChild(overlay);}const calcState={current:'0',previous:null,operator:null,justEvaluated:false,parenStack:[],exprTokens:[]};let calcDisplayEl=null;let calcExprEl=null;let calcErrorTimer=null;function parseCurrentValue(str){const normalized=String(str).replace(',','.');return parseFloat(normalized);}function pushNumToken(value,opts){const last=calcState.exprTokens[calcState.exprTokens.length-1];if(last&&last.type==='num'&&!last.sqrt){last.value=value;if(opts&&opts.sqrt)last.sqrt=true;}else{const tok={type:'num',value:value};if(opts&&opts.sqrt)tok.sqrt=true;calcState.exprTokens.push(tok);}}function pushOpToken(op){const last=calcState.exprTokens[calcState.exprTokens.length-1];if(last&&last.type==='op'){last.value=op;}else{calcState.exprTokens.push({type:'op',value:op});}}function pushParenToken(type){calcState.exprTokens.push({type:type,value:type==='open'?'(':')'});}function pushEqToken(){calcState.exprTokens.push({type:'eq',value:'='});}function renderExprText(){let out='';for(let i=0;i<calcState.exprTokens.length;i++){const tk=calcState.exprTokens[i];if(tk.type==='open')out+='(';else if(tk.type==='close')out+=')';else if(tk.type==='op')out+=' '+tk.value+' ';else if(tk.type==='eq')out+=' = ';else if(tk.type==='num'){if(tk.sqrt)out+='√('+tk.value+')';else out+=tk.value;}}return out.trim();}function calcReset(){calcState.current='0';calcState.previous=null;calcState.operator=null;calcState.justEvaluated=false;calcState.parenStack=[];calcState.exprTokens=[];}function updateCalcDisplay(){if(!calcDisplayEl)return;calcDisplayEl.textContent=calcState.current;if(calcExprEl){const txt=renderExprText();calcExprEl.textContent=txt||'\u00A0';}}function showCalcError(msg){if(!calcDisplayEl)return;calcDisplayEl.textContent=msg;if(calcExprEl)calcExprEl.textContent='';clearTimeout(calcErrorTimer);calcErrorTimer=setTimeout(()=>{calcReset();updateCalcDisplay();},1500);}function calcDigit(d){if(calcState.justEvaluated){calcState.current='0';calcState.justEvaluated=false;calcState.exprTokens=[];}const isDecimal=(d==='.'||d===',');if(isDecimal&&(calcState.current.indexOf('.')>=0||calcState.current.indexOf(',')>=0))return;if(calcState.current==='0'&&!isDecimal)calcState.current=d;else calcState.current+=d;pushNumToken(calcState.current);}function calcEvaluate(){const prev=calcState.previous;const cur=parseCurrentValue(calcState.current);let result;switch(calcState.operator){case'+':result=prev+cur;break;case'−':result=prev-cur;break;case'×':result=prev*cur;break;case'÷':if(cur===0)return{err:t('errDivZero')};result=prev/cur;break;case'^':result=Math.pow(prev,cur);break;default:result=cur;}if(!isFinite(result))return{err:t('errDivZero')};return{val:result};}function calcOperator(op){const wasJustEval=calcState.justEvaluated;calcState.justEvaluated=false;if(wasJustEval){calcState.exprTokens=[{type:'num',value:calcState.current}];}if(calcState.operator&&calcState.previous!==null){const r=calcEvaluate();if(r.err){showCalcError(r.err);return;}calcState.previous=r.val;calcState.current='0';}else{calcState.previous=parseCurrentValue(calcState.current);calcState.current='0';}calcState.operator=op;pushOpToken(op);}function calcEquals(){let guard=32;while(calcState.parenStack.length>0&&guard-- >0){const before=calcState.parenStack.length;calcCloseParen();if(calcState.parenStack.length>=before)break;}if(calcState.parenStack.length>0)return;if(calcState.operator!==null){const r=calcEvaluate();if(r.err){showCalcError(r.err);return;}calcState.current=String(Number(r.val.toPrecision(12)));calcState.previous=null;calcState.operator=null;calcState.justEvaluated=true;pushEqToken();pushNumToken(calcState.current);}else{calcState.justEvaluated=true;}}function calcSqrt(){const cur=parseCurrentValue(calcState.current);if(cur<0){showCalcError(t('errSqrt'));return;}calcState.current=String(Number(Math.sqrt(cur).toPrecision(12)));calcState.justEvaluated=true;const last=calcState.exprTokens[calcState.exprTokens.length-1];if(last&&last.type==='num'){last.value=calcState.current;last.sqrt=true;}else{calcState.exprTokens.push({type:'num',value:calcState.current,sqrt:true});}}function calcSign(){if(calcState.current.startsWith('-'))calcState.current=calcState.current.slice(1);else if(calcState.current!=='0')calcState.current='-'+calcState.current;const last=calcState.exprTokens[calcState.exprTokens.length-1];if(last&&last.type==='num')last.value=calcState.current;}function calcBackspace(){if(calcState.current.length>1){calcState.current=calcState.current.slice(0,-1);}else{calcState.current='0';}const last=calcState.exprTokens[calcState.exprTokens.length-1];if(last&&last.type==='num'){if(calcState.current==='0'&&last.value.length<=1){last.value='0';}else{last.value=calcState.current;}}}function calcOpenParen(){if(calcState.justEvaluated){calcState.current='0';calcState.justEvaluated=false;calcState.exprTokens=[];}calcState.parenStack.push({previous:calcState.previous,operator:calcState.operator});calcState.previous=null;calcState.operator=null;calcState.current='0';pushParenToken('open');}function calcCloseParen(){if(calcState.parenStack.length===0)return;let subResult;if(calcState.operator!==null&&calcState.previous!==null){const r=calcEvaluate();if(r.err){showCalcError(r.err);calcState.parenStack=[];return;}subResult=r.val;}else{subResult=parseCurrentValue(calcState.current);}const parent=calcState.parenStack.pop();calcState.previous=parent.previous;calcState.operator=parent.operator;calcState.current=String(Number(subResult.toPrecision(12)));calcState.justEvaluated=true;pushParenToken('close');}function handleCalcInput(val){if(val==='C'){calcReset();}else if(val==='BACK'){calcBackspace();}else if(val==='±'){calcSign();}else if(val==='√'){calcSqrt();}else if(val==='='){calcEquals();}else if(val==='('){calcOpenParen();}else if(val===')'){calcCloseParen();}else if(val==='+'||val==='−'||val==='×'||val==='÷'||val==='^'){calcOperator(val);}else{calcDigit(val);}updateCalcDisplay();}function buildCalculator(){if(activeOverlayEl)closeActiveOverlay();if(backgroundCalcEl){try{backgroundCalcEl.remove();}catch(e){}backgroundCalcEl=null;}pauseMusicForPrivacy();const overlay=el('div',{class:'pv-calc-fullscreen'});activeOverlayEl=overlay;const header=el('div',{class:'pv-calc-header'});
const panicBtn=el('button',{class:'pv-calc-icon-btn pv-calc-panic',type:'button',title:t('calcPanicTitle')});
panicBtn.appendChild(iconEl('eye',EYE_EMOJI,{size:20,pngFallback:PRIVACY_IMG_PATH}));
panicBtn.addEventListener('click',()=>{backgroundCalcEl=overlay;overlay.style.display='none';activeOverlayEl=null;buildBlackScreen('returnToCalc');});
header.appendChild(panicBtn);
const rightGroup=el('div',{class:'pv-calc-header-right'});const tipsBtn=el('button',{class:'pv-calc-icon-btn',type:'button',title:t('calcTipsTitle'),text:'?'});tipsBtn.addEventListener('click',openTips);rightGroup.appendChild(tipsBtn);const closeBtn=el('button',{class:'pv-calc-icon-btn',type:'button',title:t('calcCloseTitle'),text:'✕'});closeBtn.addEventListener('click',()=>{closeActiveOverlay();});rightGroup.appendChild(closeBtn);header.appendChild(rightGroup);overlay.appendChild(header);const exprEl=el('div',{style:{fontSize:'14px',color:'#888',fontFamily:'inherit',textAlign:'right',padding:'8px 24px 0',minHeight:'20px',lineHeight:'1.2',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',flexShrink:'0'}});calcExprEl=exprEl;overlay.appendChild(exprEl);const display=el('div',{class:'pv-calc-display',text:calcState.current});calcDisplayEl=display;overlay.appendChild(display);const buttons=el('div',{class:'pv-calc-buttons'});const layout=[{label:'C',val:'C',cls:'clr'},{label:'⌫',val:'BACK',cls:'op'},{label:'±',val:'±',cls:'op'},{label:'÷',val:'÷',cls:'op'},{label:'7',val:'7',cls:''},{label:'8',val:'8',cls:''},{label:'9',val:'9',cls:''},{label:'×',val:'×',cls:'op'},{label:'4',val:'4',cls:''},{label:'5',val:'5',cls:''},{label:'6',val:'6',cls:''},{label:'−',val:'−',cls:'op'},{label:'1',val:'1',cls:''},{label:'2',val:'2',cls:''},{label:'3',val:'3',cls:''},{label:'+',val:'+',cls:'op'},{label:'.',val:'.',cls:''},{label:'0',val:'0',cls:''},{label:',',val:',',cls:''},{label:'=',val:'=',cls:'eq'},{label:'(',val:'(',cls:'op'},{label:')',val:')',cls:'op'},{label:'√',val:'√',cls:'op'},{label:'x^y',val:'^',cls:'op'}];layout.forEach(b=>{const btn=el('button',{class:'pv-calc-btn '+b.cls,type:'button',text:b.label});btn.addEventListener('click',()=>handleCalcInput(b.val));buttons.appendChild(btn);});overlay.appendChild(buttons);document.body.appendChild(overlay);updateCalcDisplay();}function openCalculator(){ensureWarning(()=>{calcReset();buildCalculator();});}let tapCount=0;let tapTimer=null;function buildBlackScreen(mode){if(activeOverlayEl)closeActiveOverlay();pauseMusicForPrivacy();const overlay=el('div',{class:'pv-black-screen'});if(mode)overlay.dataset.mode=mode;activeOverlayEl=overlay;tapCount=0;clearTimeout(tapTimer);const handleTap=()=>{tapCount++;clearTimeout(tapTimer);if(tapCount>=TAPS_TO_EXIT){tapCount=0;clearTimeout(tapTimer);exitBlackScreen();return;}tapTimer=setTimeout(()=>{tapCount=0;},TAP_WINDOW_MS);};overlay.addEventListener('click',handleTap);document.body.appendChild(overlay);enterFullscreen(overlay);}function openBlackScreen(){ensureWarning(()=>buildBlackScreen());}

function buildBlackFabIcon(btn){
btn.innerHTML='';
btn.appendChild(iconEl('eye',EYE_EMOJI,{size:22,pngFallback:PRIVACY_IMG_PATH}));
}


function mount(){
const topbar=document.querySelector('.topbar');
if(!topbar)return false;
if(topbar.querySelector('.pv-right-group'))return true;
const settingsBtn=document.getElementById('nibOpenSettings');
if(!settingsBtn)return false;

const rightGroup=el('div',{class:'pv-right-group'});

const calcFab=el('button',{class:'pv-fab pv-fab-calc',type:'button',title:t('fabCalcTitle')});
calcFab.appendChild(iconEl('calc','🧮',{size:22}));
calcFab.addEventListener('click',openCalculator);
rightGroup.appendChild(calcFab);

const blackFab=el('button',{class:'pv-fab pv-fab-black',type:'button',title:t('fabBlackTitle')});
buildBlackFabIcon(blackFab);
blackFab.addEventListener('click',openBlackScreen);
rightGroup.appendChild(blackFab);

if(settingsBtn.parentNode){
settingsBtn.parentNode.removeChild(settingsBtn);
}
rightGroup.appendChild(settingsBtn);
topbar.appendChild(rightGroup);

if(console&&console.debug)console.debug('[Nibbly privacy] ✅ FABs mounted to topbar');
return true;
}

function unmount(){
const group=document.querySelector('.pv-right-group');
if(!group)return;
const settingsBtn=document.getElementById('nibOpenSettings');
if(settingsBtn&&settingsBtn.parentNode===group){
const topbar=document.querySelector('.topbar');
if(topbar)topbar.appendChild(settingsBtn);
}
group.remove();
}

function init(){loadState();mount();}
function destroy(){
if(backgroundCalcEl){try{backgroundCalcEl.remove();}catch(e){}backgroundCalcEl=null;}
closeActiveOverlay();
unmount();
document.querySelectorAll('.pv-overlay, .pv-calc-fullscreen, .pv-black-screen').forEach(node=>node.remove());
resumeMusicFromPrivacy();
}

window.NibblyPrivacy={
init:init,
destroy:destroy,
mount:mount,
unmount:unmount,
openCalculator:openCalculator,
openBlackScreen:openBlackScreen,
openTips:openTips
};

(function autoMount(){
if(window.__nibblyPrivacyAutoMounted)return;
const tryMount=()=>{
if(window.__nibblyPrivacyAutoMounted)return true;
if(mount()){window.__nibblyPrivacyAutoMounted=true;return true;}
return false;
};
if(tryMount())return;
let tries=0;
const iv=setInterval(()=>{
tries++;
if(tryMount()||tries>150){clearInterval(iv);}
},100);
})();

})();