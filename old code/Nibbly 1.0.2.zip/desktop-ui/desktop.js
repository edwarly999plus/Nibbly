(function () {
  'use strict';
  const TAB_ICONS = {
    num:   '🔢',
    txt:   '📝',
    uni:   '📊',
    pot:   '⚡',
    media: '🎵',
    calc:  '🧮',
    games: '🎮'
  };
  const TAB_ORDER = ['num', 'txt', 'uni', 'pot', 'media', 'calc', 'games'];
  let initialized = false;
  let observerActive = false;
  function injectTabIcons() {
    document.querySelectorAll('.nav-bar .tab').forEach(tab => {
      if (tab.querySelector('.tab-icon')) return;
      const tabId = tab.dataset.tab;
      const icon = TAB_ICONS[tabId];
      if (!icon) return;
      const originalText = tab.textContent.trim();
      const originalI18n = tab.dataset.i18n;
      tab.textContent = '';
      const iconEl = document.createElement('span');
      iconEl.className = 'tab-icon';
      iconEl.setAttribute('aria-hidden', 'true');
      iconEl.textContent = icon;
      const labelEl = document.createElement('span');
      labelEl.className = 'tab-label';
      labelEl.textContent = originalText;
      if (originalI18n) {
        labelEl.dataset.i18n = originalI18n;
      }
      tab.appendChild(iconEl);
      tab.appendChild(labelEl);
      delete tab.dataset.i18n;
    });
  }
  function watchNavBar() {
    if (observerActive) return;
    const navBar = document.querySelector('.nav-bar');
    if (!navBar || typeof MutationObserver === 'undefined') return;
    observerActive = true;
    const observer = new MutationObserver(() => {
      const tabs = navBar.querySelectorAll('.tab');
      let needsReinject = false;
      tabs.forEach(tab => {
        if (!tab.querySelector('.tab-icon') && TAB_ICONS[tab.dataset.tab]) {
          needsReinject = true;
        }
      });
      if (needsReinject) {
        injectTabIcons();
      }
    });
    observer.observe(navBar, {
      childList: true,
      subtree: false
    });
  }
  function addVersionBadge() {
    const brand = document.querySelector('.topbar .brand');
    if (!brand || brand.querySelector('.version-badge')) return;
    const h1 = brand.querySelector('h1');
    if (!h1) return;
    const badge = document.createElement('span');
    badge.className = 'version-badge';
    badge.textContent = 'v1.0.2';
    h1.appendChild(badge);
  }
  function addKeyboardShortcuts() {
    if (window.__nibblyDesktopShortcuts) return;
    window.__nibblyDesktopShortcuts = true;
    document.addEventListener('keydown', (e) => {
      if (!document.body.classList.contains('desktop-ui')) return;
      const tag = (e.target.tagName || '').toUpperCase();
      if (tag === 'INPUT' || tag === 'TEXTAREA' || e.target.isContentEditable) return;
      if (e.ctrlKey || e.metaKey || e.altKey || e.shiftKey) return;
      if (e.key === 'Escape') {
        const sheet = document.getElementById('sheet');
        if (sheet && sheet.classList.contains('show')) {
          e.preventDefault();
          const closeBtn = document.getElementById('closeSettings');
          if (closeBtn) closeBtn.click();
        }
        return;
      }
      const num = parseInt(e.key, 10);
      if (num >= 1 && num <= TAB_ORDER.length) {
        const tab = document.querySelector(
          '.tab[data-tab="' + TAB_ORDER[num - 1] + '"]'
        );
        if (tab && !tab.disabled) {
          e.preventDefault();
          tab.click();
        }
      }
    }, true);
  }
  function addCardHover() {
    if (document.body.classList.contains('no-effects')) return;
    document.querySelectorAll('.panel .card').forEach(card => {
      if (card.dataset.desktopHover) return;
      card.dataset.desktopHover = '1';
      card.addEventListener('mouseenter', () => {
        card.style.transition = 'box-shadow .22s ease';
        card.style.boxShadow = '0 4px 24px rgba(0, 0, 0, .15)';
      });
      card.addEventListener('mouseleave', () => {
        card.style.boxShadow = '';
      });
    });
  }
  function init() {
    if (initialized) {
      injectTabIcons();
      addCardHover();
      return;
    }
    initialized = true;
    if (typeof requestAnimationFrame === 'function') {
      requestAnimationFrame(() => {
        injectTabIcons();
        watchNavBar();
        addVersionBadge();
        addKeyboardShortcuts();
        addCardHover();
      });
    } else {
      setTimeout(() => {
        injectTabIcons();
        watchNavBar();
        addVersionBadge();
        addKeyboardShortcuts();
        addCardHover();
      }, 0);
    }
  }
  window.NibblyDesktop = {
    init: init,
    refresh: init
  };
  if (document.body && document.body.classList.contains('desktop-ui')) {
    init();
  }
})();