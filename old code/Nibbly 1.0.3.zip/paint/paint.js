(function () {
  'use strict';

  /* ---------- i18n ---------- */
  const I18N = {
    es: {
      'brush': 'Pincel',
      'pencil': 'Lápiz',
      'eraser': 'Borrador',
      'picker': 'Gotero',
      'thickness': 'Grosor',
      'clear': 'Limpiar',
      'copyBoth': 'Copiar ambos',
      'copyRgba': 'Copiar RGBA',
      'copyHex': 'Copiar HEX',
      'copied': '✓',
      'hint': 'Pincel: trazos suaves · Lápiz: pixel a pixel · Borrador: transparente · Gotero: toca el lienzo',
      'error': 'No se encontraron los archivos de Paint'
    },
    en: {
      'brush': 'Brush',
      'pencil': 'Pencil',
      'eraser': 'Eraser',
      'picker': 'Dropper',
      'thickness': 'Thickness',
      'clear': 'Clear',
      'copyBoth': 'Copy both',
      'copyRgba': 'Copy RGBA',
      'copyHex': 'Copy HEX',
      'copied': '✓',
      'hint': 'Brush: smooth strokes · Pencil: pixel by pixel · Eraser: transparent · Dropper: tap the canvas',
      'error': 'Paint files not found'
    }
  };

  function getLang() {
    try {
      const raw = localStorage.getItem('nibbly-settings-v2');
      if (raw) {
        const s = JSON.parse(raw);
        if (s && s.lang === 'en') return 'en';
      }
    } catch (e) {}
    return 'es';
  }
  function t(key) {
    const lang = getLang();
    return (I18N[lang] && I18N[lang][key]) || I18N.es[key] || key;
  }

  /* ---------- Helpers ---------- */
  function el(tag, attrs, children) {
    const node = document.createElement(tag);
    if (attrs) {
      for (const k in attrs) {
        if (k === 'class') node.className = attrs[k];
        else if (k === 'text') node.textContent = attrs[k];
        else if (k === 'html') node.innerHTML = attrs[k];
        else if (k === 'style' && typeof attrs[k] === 'object') {
          for (const sk in attrs[k]) node.style[sk] = attrs[k][sk];
        } else if (k.startsWith('data-') || k.startsWith('aria-')) {
          node.setAttribute(k, attrs[k]);
        } else {
          node[k] = attrs[k];
        }
      }
    }
    if (children) {
      if (Array.isArray(children)) children.forEach(c => c && node.appendChild(c));
      else if (typeof children === 'string') node.textContent = children;
      else node.appendChild(children);
    }
    return node;
  }
  function clearNode(n) { while (n.firstChild) n.removeChild(n.firstChild); }

  async function copyToClipboard(text) {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
        return true;
      }
    } catch (e) {}
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.top = '-1000px';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      ta.setSelectionRange(0, text.length);
      const ok = document.execCommand('copy');
      document.body.removeChild(ta);
      return ok;
    } catch (e) { return false; }
  }

  /* Feedback visual de "copiado" */
  function flashCopied(btn, originalText) {
    btn.textContent = t('copied');
    btn.disabled = true;
    setTimeout(() => {
      btn.textContent = originalText;
      btn.disabled = false;
    }, 1000);
  }

  /* Bresenham: pixel perfect (no antialiasing) */
  function bresenhamLine(x0, y0, x1, y1, plotFn) {
    const dx = Math.abs(x1 - x0);
    const dy = Math.abs(y1 - y0);
    const sx = x0 < x1 ? 1 : -1;
    const sy = y0 < y1 ? 1 : -1;
    let err = dx - dy;
    while (true) {
      plotFn(x0, y0);
      if (x0 === x1 && y0 === y1) break;
      const e2 = 2 * err;
      if (e2 > -dy) { err -= dy; x0 += sx; }
      if (e2 < dx) { err += dx; y0 += sy; }
    }
  }

  /* "#RRGGBB" to {r,g,b} */
  function hexToRgb(hex) {
    const s = hex.replace('#', '');
    return {
      r: parseInt(s.substring(0, 2), 16) || 0,
      g: parseInt(s.substring(2, 4), 16) || 0,
      b: parseInt(s.substring(4, 6), 16) || 0
    };
  }

  /* ---------- App Paint ---------- */
  const Paint = {
    canvas: null,
    ctx: null,
    tool: 'brush',
    color: '#5b8cff',
    thickness: 4,
    isDrawing: false,
    lastX: 0,
    lastY: 0,
    canvasW: 0,
    canvasH: 0,
    _pointerDown: null,
    _pointerMove: null,
    _pointerUp: null,

    init(stage) {
      clearNode(stage);
      const isDesktop = document.body.classList.contains('desktop-ui');

      this.canvasW = isDesktop ? 500 : 320;
      this.canvasH = isDesktop ? 400 : 320;

      const wrap = el('div', { class: 'paint-app' });

      /* ── Toolbar 1: tools ── */
      const toolbar = el('div', { class: 'paint-toolbar' });
      const tools = [
        { id: 'brush',  icon: '🖌️', label: t('brush')  },
        { id: 'pencil', icon: '✏️', label: t('pencil') },
        { id: 'eraser', icon: '🧽', label: t('eraser') },
        { id: 'picker', icon: '💧', label: t('picker') }
      ];
      const toolBtns = {};
      tools.forEach(tool => {
        const btn = el('button', {
          class: 'paint-tool' + (tool.id === this.tool ? ' active' : ''),
          type: 'button',
          title: tool.label
        });
        btn.appendChild(el('span', { class: 'paint-tool-icon', text: tool.icon }));
        btn.appendChild(el('span', { class: 'paint-tool-label', text: tool.label }));
        btn.addEventListener('click', () => {
          this.tool = tool.id;
          Object.keys(toolBtns).forEach(k => {
            toolBtns[k].classList.toggle('active', k === tool.id);
          });
          this.updateCursor();
        });
        toolBtns[tool.id] = btn;
        toolbar.appendChild(btn);
      });
      wrap.appendChild(toolbar);

      /* ── Toolbar 2 ── */
      const toolbar2 = el('div', { class: 'paint-toolbar-2' });

      const thicknessWrap = el('div', { class: 'paint-thickness' });
      thicknessWrap.appendChild(el('label', { text: t('thickness') }));
      const slider = el('input', {
        type: 'range', min: '1', max: '40', value: String(this.thickness),
        class: 'paint-slider'
      });
      const thickVal = el('span', { class: 'paint-thick-val', text: this.thickness + 'px' });
      slider.addEventListener('input', () => {
        this.thickness = parseInt(slider.value, 10);
        thickVal.textContent = this.thickness + 'px';
      });
      thicknessWrap.appendChild(slider);
      thicknessWrap.appendChild(thickVal);
      toolbar2.appendChild(thicknessWrap);

      const colorWrap = el('label', { class: 'paint-color-wrap' });
      const colorDot = el('span', { class: 'paint-color-dot', style: { background: this.color } });
      colorWrap.appendChild(colorDot);
      const colorInput = el('input', {
        type: 'color', value: this.color, class: 'paint-color-input'
      });
      colorInput.addEventListener('input', () => {
        this.color = colorInput.value;
        colorDot.style.background = this.color;
        const rgb = hexToRgb(this.color);
        this.updateColorInfo(rgb.r, rgb.g, rgb.b, 255);
      });
      colorWrap.appendChild(colorInput);
      toolbar2.appendChild(colorWrap);

      const clearBtn = el('button', {
        class: 'paint-clear', type: 'button', text: t('clear')
      });
      clearBtn.addEventListener('click', () => {
        this.ctx.clearRect(0, 0, this.canvasW, this.canvasH);
        this.updateColorInfo(0, 0, 0, 0);
      });
      toolbar2.appendChild(clearBtn);

      wrap.appendChild(toolbar2);

      /* ── Canvas ── */
      const canvasWrap = el('div', { class: 'paint-canvas-wrap' });
      const canvas = el('canvas', {
        class: 'paint-canvas',
        width: String(this.canvasW),
        height: String(this.canvasH)
      });
      this.canvas = canvas;
      this.ctx = canvas.getContext('2d', { willReadFrequently: true });
      this.ctx.lineCap = 'round';
      this.ctx.lineJoin = 'round';
      canvasWrap.appendChild(canvas);
      wrap.appendChild(canvasWrap);

      const colorInfo = el('div', { class: 'paint-color-info' });

      const rgbaRow = el('div', { class: 'paint-color-info-row' });
      rgbaRow.appendChild(el('span', { class: 'paint-info-label', text: 'RGBA:' }));
      const rgbaEl = el('code', { class: 'paint-rgba', text: 'rgba(0, 0, 0, 0.00)' });
      rgbaRow.appendChild(rgbaEl);
      const copyRgbaBtn = el('button', {
        class: 'paint-copy-mini',
        type: 'button',
        title: t('copyRgba'),
        text: '📋'
      });
      copyRgbaBtn.addEventListener('click', async () => {
        const ok = await copyToClipboard(rgbaEl.textContent);
        if (ok) flashCopied(copyRgbaBtn, '📋');
      });
      rgbaRow.appendChild(copyRgbaBtn);
      colorInfo.appendChild(rgbaRow);

      
      const hexRow = el('div', { class: 'paint-color-info-row' });
      hexRow.appendChild(el('span', { class: 'paint-info-label', text: 'HEX:' }));
      const hexEl = el('code', { class: 'paint-hex', text: '#00000000' });
      hexRow.appendChild(hexEl);
      const copyHexBtn = el('button', {
        class: 'paint-copy-mini',
        type: 'button',
        title: t('copyHex'),
        text: '📋'
      });
      copyHexBtn.addEventListener('click', async () => {
        const ok = await copyToClipboard(hexEl.textContent);
        if (ok) flashCopied(copyHexBtn, '📋');
      });
      hexRow.appendChild(copyHexBtn);
      colorInfo.appendChild(hexRow);

      
      const copyBothBtn = el('button', {
        class: 'paint-copy',
        type: 'button',
        text: t('copyBoth')
      });
      copyBothBtn.addEventListener('click', async () => {
        const text = hexEl.textContent + '\n' + rgbaEl.textContent;
        const ok = await copyToClipboard(text);
        if (ok) flashCopied(copyBothBtn, t('copyBoth'));
      });
      colorInfo.appendChild(copyBothBtn);

      wrap.appendChild(colorInfo);
      wrap.appendChild(el('div', { class: 'paint-hint', text: t('hint') }));
      stage.appendChild(wrap);

      this.setupDrawing();
      this.updateColorInfo(0, 0, 0, 0);
      this.updateCursor();
    },

    updateCursor() {
      const cursors = { brush: 'crosshair', pencil: 'crosshair', eraser: 'crosshair', picker: 'copy' };
      if (this.canvas) this.canvas.style.cursor = cursors[this.tool] || 'crosshair';
    },

    updateColorInfo(r, g, b, a) {
      const aFloat = (a / 255);
      const rgba = 'rgba(' + r + ', ' + g + ', ' + b + ', ' + aFloat.toFixed(2) + ')';
      const hex = '#' + [r, g, b, a]
        .map(v => v.toString(16).padStart(2, '0')).join('').toUpperCase();
      const info = this.canvas.parentElement.parentElement;
      const rgbaEl = info.querySelector('.paint-rgba');
      const hexEl = info.querySelector('.paint-hex');
      if (rgbaEl) rgbaEl.textContent = rgba;
      if (hexEl) hexEl.textContent = hex;
    },

    getPos(e) {
      const canvas = this.canvas;
      const rect = canvas.getBoundingClientRect();
      const scaleX = canvas.width / rect.width;
      const scaleY = canvas.height / rect.height;
      return {
        x: Math.floor((e.clientX - rect.left) * scaleX),
        y: Math.floor((e.clientY - rect.top) * scaleY)
      };
    },

    pickAt(pos) {
      try {
        const data = this.ctx.getImageData(pos.x, pos.y, 1, 1).data;
        this.updateColorInfo(data[0], data[1], data[2], data[3]);
        if (data[3] > 0) {
          const hex = '#' + [data[0], data[1], data[2]]
            .map(v => v.toString(16).padStart(2, '0')).join('');
          this.color = hex;
          const info = this.canvas.parentElement.parentElement;
          const colorInput = info.querySelector('.paint-color-input');
          const colorDot = info.querySelector('.paint-color-dot');
          if (colorInput) colorInput.value = hex;
          if (colorDot) colorDot.style.background = hex;
        }
      } catch (e) {}
    },

    drawDot(x, y) {
      const ctx = this.ctx;
      ctx.save();
      if (this.tool === 'pencil') {
        ctx.globalCompositeOperation = 'source-over';
        ctx.fillStyle = this.color;
        const size = Math.max(1, this.thickness);
        const half = Math.floor(size / 2);
        ctx.fillRect(x - half, y - half, size, size);
        const rgb = hexToRgb(this.color);
        this.updateColorInfo(rgb.r, rgb.g, rgb.b, 255);
      } else if (this.tool === 'eraser') {
        ctx.globalCompositeOperation = 'destination-out';
        ctx.beginPath();
        ctx.arc(x, y, this.thickness / 2, 0, Math.PI * 2);
        ctx.fill();
        this.updateColorInfo(0, 0, 0, 0);
      } else {
        ctx.globalCompositeOperation = 'source-over';
        ctx.fillStyle = this.color;
        ctx.beginPath();
        ctx.arc(x, y, this.thickness / 2, 0, Math.PI * 2);
        ctx.fill();
        const rgb = hexToRgb(this.color);
        this.updateColorInfo(rgb.r, rgb.g, rgb.b, 255);
      }
      ctx.restore();
    },

    drawLine(x0, y0, x1, y1) {
      const ctx = this.ctx;
      if (this.tool === 'pencil') {
        ctx.save();
        ctx.globalCompositeOperation = 'source-over';
        ctx.fillStyle = this.color;
        const size = Math.max(1, this.thickness);
        const half = Math.floor(size / 2);
        bresenhamLine(x0, y0, x1, y1, (x, y) => {
          ctx.fillRect(x - half, y - half, size, size);
        });
        ctx.restore();
        return;
      }
      ctx.save();
      if (this.tool === 'eraser') {
        ctx.globalCompositeOperation = 'destination-out';
      } else {
        ctx.globalCompositeOperation = 'source-over';
        ctx.strokeStyle = this.color;
      }
      ctx.lineWidth = this.thickness;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(x0 + 0.5, y0 + 0.5);
      ctx.lineTo(x1 + 0.5, y1 + 0.5);
      ctx.stroke();
      ctx.restore();
    },

    setupDrawing() {
      const canvas = this.canvas;

      const start = (pos) => {
        if (this.tool === 'picker') {
          this.pickAt(pos);
          return;
        }
        this.isDrawing = true;
        this.lastX = pos.x;
        this.lastY = pos.y;
        this.drawDot(pos.x, pos.y);
      };

      const move = (pos) => {
        if (this.tool === 'picker') {
          this.pickAt(pos);
          return;
        }
        if (!this.isDrawing) return;
        this.drawLine(this.lastX, this.lastY, pos.x, pos.y);
        this.lastX = pos.x;
        this.lastY = pos.y;
      };

      const end = () => { this.isDrawing = false; };

      if (window.PointerEvent) {
        this._pointerDown = (e) => {
          e.preventDefault();
          canvas.setPointerCapture(e.pointerId);
          start(this.getPos(e));
        };
        this._pointerMove = (e) => {
          if (e.buttons === 0 && !this.isDrawing && this.tool !== 'picker') return;
          move(this.getPos(e));
        };
        this._pointerUp = (e) => {
          end();
          try { canvas.releasePointerCapture(e.pointerId); } catch (err) {}
        };
        canvas.addEventListener('pointerdown', this._pointerDown);
        canvas.addEventListener('pointermove', this._pointerMove);
        canvas.addEventListener('pointerup', this._pointerUp);
        canvas.addEventListener('pointercancel', this._pointerUp);
        canvas.addEventListener('pointerleave', end);
      } else {
        canvas.addEventListener('mousedown', (e) => { e.preventDefault(); start(this.getPos(e)); });
        canvas.addEventListener('mousemove', (e) => move(this.getPos(e)));
        canvas.addEventListener('mouseup', end);
        canvas.addEventListener('mouseleave', end);
        canvas.addEventListener('touchstart', (e) => {
          e.preventDefault();
          const t0 = e.touches[0];
          start(this.getPos(t0));
        }, { passive: false });
        canvas.addEventListener('touchmove', (e) => {
          e.preventDefault();
          const t0 = e.touches[0];
          move(this.getPos(t0));
        }, { passive: false });
        canvas.addEventListener('touchend', (e) => { e.preventDefault(); end(); }, { passive: false });
        canvas.addEventListener('touchcancel', end);
      }
    },

    pause() {},
    resume() {}
  };

  /* ---------- Public API ---------- */
  window.NibblyPaint = {
    init(container) {
      if (!container) return;
      try {
        Paint.init(container);
      } catch (e) {
        console.error('[NibblyPaint] init error:', e);
        container.innerHTML =
          '<div class="paint-error"><span class="emoji">🎨</span>' +
          t('error') + ': ' + (e && e.message ? e.message : 'unknown') +
          '</div>';
      }
    }
  };
})();